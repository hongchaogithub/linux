#!/bin/bash
ps -aux |grep -E "fk.disp|elsfk"|grep -Ev "vim|grep"
for i in $(ps -aux |grep -E "fk.disp|elsfk"|grep -Ev "vim|grep"|awk '{print $2}')
   do
    kill -9 $i
   done

